Kyle Lam
ICS4U1
2D Array - Boggle Word Search

===READ ME===

Instructions: 
It is recommended to put the 'wordlist.txt' in the root file (alongside with files such as 'src')
The directory of the 'wordlist.txt' should be like this: "...\Boggle\wordlist.txt"
In case the program somehow did not function properly, a zip file containing the entire root of the program is provided as well.
Thank you very much for reading the read me file
